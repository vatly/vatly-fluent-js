# One-Off Products

One-off products are single-purchase items (no recurring billing). They can be
created, updated, archived, and unarchived through the API.

> **Authoritative field reference.** This page covers the common cases. The complete, canonical schema lives in the [OpenAPI spec](https://docs.vatly.com/openapi.yaml) (see the `OneOffProduct` schema). When in doubt, trust the spec.

## The One-Off Product resource

| Name | Type | Description |
| --- | --- | --- |
| `id` | `string` | Unique identifier (`one_off_product_…`). |
| `resource` | `string` | Always `one_off_product`. |
| `name` | `string` | Display name. |
| `description` | `string \| null` | Optional description. |
| `basePrice` | `Money` | Price, e.g. `{ value: "49.00", currency: "EUR" }`. |
| `status` | `string` | `active`, `pending`, or `rejected`. Archive state is separate in `archivedAt`. |
| `createdAt` | `string` | Creation timestamp (ISO 8601). |
| `testmode` | `boolean` | Whether this is a test product. |

## Retrieve a one-off product

`GET /v1/one-off-products/{oneOffProductId}`

```ts
const product = await vatly.oneOffProducts.get("one_off_product_abc123");
```

## List one-off products

`GET /v1/one-off-products`

```ts
const page = await vatly.oneOffProducts.list({ limit: 25 });

for await (const product of vatly.oneOffProducts.listAll()) {
  // ...
}
```

To sell a one-off product, pass its `id` in a [checkout](Checkouts.md)'s `products`.

## Create, update and archive

```ts
const product = await vatly.oneOffProducts.create({
  name: "Premium License", description: "Lifetime access", productType: "saas",
  basePrice: { value: "99.00", currency: "EUR" }, taxBehavior: "exclusive",
});
await vatly.oneOffProducts.update(product.id, { name: "Premium License v2" });
await vatly.oneOffProducts.archive(product.id); // 204: no return value
const restored = await vatly.oneOffProducts.unarchive(product.id);
const all = await vatly.oneOffProducts.list({ includeArchived: true });
```

`productType` is `saas` or `ebook`. Creation and updates may require approval;
inspect `status`, `pendingUpdates`, and `updateStatus` rather than assuming the
requested values are already live. `taxBehavior` is immutable after creation.
