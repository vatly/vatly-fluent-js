# Subscription Plans

Subscription plans define recurring products, prices, and billing intervals.
The API supports creation, updates, archive and unarchive.

For all fields and options, see the [Subscription Plans API reference](https://docs.vatly.com/api-reference/subscription-plans). The [OpenAPI spec](https://docs.vatly.com/openapi.yaml) is also available for tooling.

## The Subscription Plan resource

| Name | Type | Description |
| --- | --- | --- |
| `id` | `string` | Unique identifier (`subscription_plan_…`). |
| `resource` | `string` | Always `subscription_plan`. |
| `name` | `string` | Display name. |
| `description` | `string \| null` | Optional description. |
| `basePrice` | `Money` | Price per interval, e.g. `{ value: "29.00", currency: "EUR" }`. |
| `interval` / `intervalCount` | `string` / `number` | Billing cadence: `month` × 1 or `year` × 1. Plans created earlier may still return `day`, `week`, or a higher count. |
| `status` | `string` | `active`, `pending`, or `rejected`. Archive state is separate in `archivedAt`. |
| `createdAt` | `string` | Creation timestamp (ISO 8601). |
| `testmode` | `boolean` | Whether this is a test plan. |

## Retrieve a subscription plan

`GET /v1/subscription-plans/{subscriptionPlanId}`

```ts
const plan = await vatly.subscriptionPlans.get("subscription_plan_abc123");
console.log(plan.basePrice.value, plan.basePrice.currency);
```

## List subscription plans

`GET /v1/subscription-plans`

```ts
const page = await vatly.subscriptionPlans.list({ limit: 25 });

for await (const plan of vatly.subscriptionPlans.listAll()) {
  // ...
}
```

To sell a plan, pass its `id` in a [checkout](Checkouts.md)'s `products`.

## Create, update and archive

```ts
const plan = await vatly.subscriptionPlans.create({
  name: "Pro Monthly", description: "Pro features", productType: "saas",
  basePrice: { value: "29.00", currency: "EUR" }, interval: "month", intervalCount: 1,
});
await vatly.subscriptionPlans.update(plan.id, { interval: "year", intervalCount: 1 });
await vatly.subscriptionPlans.archive(plan.id); // 204: no return value
const restored = await vatly.subscriptionPlans.unarchive(plan.id);
const all = await vatly.subscriptionPlans.list({ includeArchived: true });
```

New prices are EUR-only. `taxBehavior` defaults to `exclusive` and is immutable.
Plans sell `saas` only. New and updated plans bill monthly (`interval: "month"`,
`intervalCount: 1`) or yearly (`interval: "year"`, `intervalCount: 1`), in both
live and test mode; anything else returns `422`. When updating, send `interval`
and `intervalCount` together. Plans already on another interval keep working and
can be updated without sending the interval. Creation and updates may require
approval; inspect `status`, `pendingUpdates`, and `updateStatus`.
