# Refunds

A refund returns funds to a customer for an order. Refunds are **created** against an order (see [Orders](Orders.md#refunds-on-an-order)); the top-level `refunds` resource lets you list and retrieve them across all orders.

For all fields and options, see the [Refunds API reference](https://docs.vatly.com/api-reference/global-refunds) and [creating order refunds](https://docs.vatly.com/api-reference/refunds). The [OpenAPI spec](https://docs.vatly.com/openapi.yaml) is also available for tooling.

## The Refund resource

| Name | Type | Description |
| --- | --- | --- |
| `id` | `string` | Unique identifier (`refund_…`). |
| `customerId` | `string` | The customer being refunded. |
| `originalOrderId` | `string` | The order this refund is against. |
| `status` | `string` | `pending`, `queued`, `processing`, `refunded`, `failed`, or `canceled`. The success event is `refund.completed`, but the status is `refunded`. |
| `total` | `Money` | Gross amount refunded (incl. tax). |
| `subtotal` | `Money` | Net amount refunded (excl. tax). |
| `taxSummary` | `array` | Per-rate VAT breakdown of the refund. |
| `metadata` | `object \| null` | The `metadata` sent when the refund was created; `null` when none was sent. |
| `testmode` | `boolean` | Whether this is a test refund. |

## Retrieve a refund

`GET /v1/refunds/{refundId}`

```ts
const refund = await vatly.refunds.get("refund_abc123");
```

## List refunds

`GET /v1/refunds`

```ts
const page = await vatly.refunds.list({ limit: 25 });

for await (const refund of vatly.refunds.listAll()) {
  // ...
}
```

## Creating refunds

Create refunds against an order with `orders.createRefund` / `orders.createFullRefund`:

```ts
await vatly.orders.createRefund("order_abc123", {
  items: [{ itemId: "order_item_abc123", amount: { value: "15.00", currency: "EUR" } }],
  metadata: { ticketId: "SUPPORT-12345" },
});

await vatly.orders.createFullRefund("order_abc123", { metadata: { reason: "cancellation" } });
```

`metadata` is optional and follows the same rules as on checkouts and customers:
string values, at most 50 keys, keys up to 40 characters, values up to 500
characters. It is returned on the refund and in refund webhooks.

Only sales (checkout and subscription orders) can be refunded. For any other
order, such as a payment-method authorization, the API returns `422` with
`details.orderType` naming the order's type.

Listen for the `refund.completed` / `refund.failed` / `refund.canceled` webhooks
to reconcile your local records — the webhook payload carries the full tax
breakdown, so no follow-up call is needed.
